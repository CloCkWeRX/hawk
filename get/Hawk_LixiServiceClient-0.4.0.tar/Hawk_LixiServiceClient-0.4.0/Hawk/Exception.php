<?php
class Hawk_Exception extends Exception {}