Hawk_LixiServiceClient
======================
